import profile from '../assets./bechkam.png';
function College(){
    const myStyle={
        color:'yellow',
        backgroundColor:'blue'
    }
    return(
        <div>
            <h3 style={{backgroundColor:'red'}}>College details</h3>
            <h3 style={myStyle}>SRM college</h3>
        </div>
    )
}
function School(){
    return(
        <div>
        <h3>Schoole details</h3>
        <h3>iit madras</h3>
        <img src="profile" alt="profile" />
        </div>
    )
}
export{College,School};
