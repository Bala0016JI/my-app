// const Justname= [{Id:1,Firstname:"ram",Age:25},{Id:2,Firstname:"Radha",Age:14},{Id:3,Firstname:"Rahul",Age:15}]


// export{Justname};