import "../Signup/Signup.css";
import { Link } from 'react-router-dom';
import { useState } from "react";
function Signup() {
 let initialdata ={
    uname:'',
    password:'',
    confirmPwd:'',
    email:''
 }
    
    const [details,setDetails]=useState(initialdata)
    let handleSubmit=(e)=>{
        e.preventDefault();
        let data=[];
        if(localStorage.getItem('signupDetails') === null){
            data.push(details);
        }else{
            data= JSON.parse(localStorage.getItem('signupDetails'));
            data.push(details);
        }
        localStorage.setItem('signupDetails',JSON.stringify(data))
        alert("your information saved in the local Storage");
        console.log(details)

    }
    let handleInput=(e)=>{
        const { name, value } = e.target;
        setDetails({
            ...details,
            [name]:value,
        });

    //   let name=e.target.name;
    //   let value=e.target.value;
      //spread operator -arr,obj -clone value 
    //   console.log(name,value);
    //   let d={...details}
    //   d[name]=value;
    //   setDetails(d);
    }

    let handledelete=()=>{
        // localStorage.clear();
    }
    return (
        <div>
            <form onSubmit={handleSubmit}>
            <fieldset className="szero">
                <h2 id="sid">SIGNUP</h2>
                <div className="sfirst">
                    <label htmlFor="name">Name</label>
                    <input type="text" name="uname" placeholder="Yourname" onInput={handleInput}  value={details.uname} />
                </div>
                <div className="ssecond">

                    <label htmlFor="password">Password</label>
                    <input type="password" name="password" placeholder="Password" onInput={handleInput}  value={details.password} />
                </div>

                <div className="ssecond">

                    <label htmlFor="password">Confirm Password</label>
                    <input type="password" name="confirmPwd" placeholder="Password" onInput={handleInput}  value={details.confirmPwd} />
                </div>

                <div className="ssecond">

                    <label htmlFor="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter Email" onInput={handleInput}  value={details.email} />
                </div>

                <div className="sthird">
                    <button>
                        Signup
                    </button>
                </div>
                <div className="sfivth">
                    <p onClick={handledelete}>Already have an Account?<span><Link to="/login">Login here</Link></span></p>
                </div>
            </fieldset>
            </form>
        </div>
    )
}

export default Signup;