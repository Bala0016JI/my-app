import"../Home/Home.css";
import React from "react";
import wallpaper from "../images/download.png";
export default function Home(){
    return (
        <div className="wallpaperjh">
            <img src={wallpaper} alt="homebutton" />

        </div>
    )
}