const RelationshipDetails = [{ id: 1, label: 'Select Relationship', value: "" }, { id: 2, label: 'Father', value: "Father" }, { id: 3, label: 'Mother', value: "Mother" }, { id: 4, label: "MySelf", value: "MySelf" }];

export default RelationshipDetails;
