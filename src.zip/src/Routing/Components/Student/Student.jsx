import "./Student.css";
import moment from "moment/moment";
// import { Justname } from "../components/Content";
export default function Student (){
    let Justname= [{Id:1,Firstname:"ram",Age:25,dob:"20/12/22"},{Id:2,Firstname:"Radha",Age:14,dob:"21/12/22"},{Id:3,Firstname:"Rahul",Age:15,dob:"22/12/22"}]
    
    let dateFormat = (date) =>{
        return moment(date,'DD-MM-YY').format('DD-MMM-YYYY')
    }

    return(
        <div className="student">
          <h4>Student Details</h4>
          <table id="bala">
            <thead>
                <tr>
                    <th>StudentID</th>
                    <th>Firstname</th>
                    <th>Age</th>
                    <th>Category</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                {
                    Justname.map((abcd,Id) =>{
                        return(
                            <tr key={Id}>
                                <td>{abcd.Id}</td>
                                <td>{abcd.Firstname}</td>
                                <td>{abcd.Age}</td>
                                <td>{abcd.Age >18?"adult":"child"}</td>
                                <td>{dateFormat(abcd.dob)}</td>
                                {/* <td>{category?"Adult":"child"}</td> */}
                            </tr>
                        )
                    })
                }
            </tbody>
          </table>
        </div>

     )


    
}