import axios from "axios";
import { useEffect, useState } from "react"
import { ENV_URL } from "../APIURL";

export default  function ProfileView(){
    const [profileDetails,setProfileDetails] =useState([]);
    useEffect(()=>{

       axios.get(ENV_URL).then(response=>{
        console.log("response",response)
        setProfileDetails(response.data)
       }).catch(err=>{
        console.log("err",err)
       })

    },[])
    return(
        <div>
        <h1>Profile View</h1>
        {JSON.stringify(profileDetails)}
        </div>
    )
}